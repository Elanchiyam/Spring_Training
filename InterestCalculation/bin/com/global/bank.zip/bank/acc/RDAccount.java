package com.global.bank.acc;

public class RDAccount extends Account {
	
	
	public RDAccount(int tenure, float principal) {
		super(tenure, principal);
		// TODO Auto-generated constructor stub
	}

	@Override
	public float calculateInterest() {
		// TODO Auto-generated method stub
		float r = getRateOfInterest()/100;
        int n = 4;
        int t = getTenure();
        int nt = n*t;
        
        float base = 1+(r/n);
        float power = 1;
        
        
        for(int i = 1; i < nt; i++) {
            power = power * base;
        }
        
        return (float) (principal * (Math.pow(base, nt))-1);
	}

	@Override
	public float calculateAmountDeposited() {
		// TODO Auto-generated method stub
		float amt = this.principal * this.tenure *12;
		return amt;
	}

}
