package com.global.beans;

public enum Role {
	Customer,
	Seller
}
