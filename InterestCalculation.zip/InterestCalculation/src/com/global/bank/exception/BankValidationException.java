package com.global.bank.exception;

public class BankValidationException extends Exception{

	
	
	@Override
	public String toString() {
		return "Invalid Data";
	}
	
}
